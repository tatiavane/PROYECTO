/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import FiveCodMover.FiveCodMoverJFrame;
import java.awt.BorderLayout;

/**
 *
 * @author Diego Castro
 */
public class Menu_Principal extends javax.swing.JFrame {

    public Menu_Principal() 
    {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        BarraTitulo = new javax.swing.JPanel();
        lblMinimizar = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Contenedor = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnConfig = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        PanelTrabajador = new javax.swing.JPanel();
        LineTrabajador = new javax.swing.JPanel();
        lblTrabajador = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        PanelCliente = new javax.swing.JPanel();
        LineCliente = new javax.swing.JPanel();
        lblCliente = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        PanelUsuarios = new javax.swing.JPanel();
        LineUsuarios = new javax.swing.JPanel();
        lblUsuario = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        PanelProyecto = new javax.swing.JPanel();
        LineProyecto = new javax.swing.JPanel();
        lblProyecto = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        PanelBodega = new javax.swing.JPanel();
        LineBodega = new javax.swing.JPanel();
        lblBodega = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        PanelReportes = new javax.swing.JPanel();
        LineReportes = new javax.swing.JPanel();
        lblReporte = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        PanelEmpresa = new javax.swing.JPanel();
        LineEmpresa = new javax.swing.JPanel();
        lblEmpresa = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        PanelHistorial = new javax.swing.JPanel();
        LineHistorial = new javax.swing.JPanel();
        lblHistorial = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        BarraTitulo.setBackground(new java.awt.Color(33, 50, 66));
        BarraTitulo.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                BarraTituloMouseDragged(evt);
            }
        });
        BarraTitulo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BarraTituloMousePressed(evt);
            }
        });
        BarraTitulo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblMinimizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/Minimizar (2).png"))); // NOI18N
        lblMinimizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMinimizarMouseClicked(evt);
            }
        });
        BarraTitulo.add(lblMinimizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 0, -1, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/Cerrar.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        BarraTitulo.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 0, -1, 40));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/Icono_Verde.jpg"))); // NOI18N
        BarraTitulo.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 12, 19, 20));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Activo");
        BarraTitulo.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 12, -1, -1));

        Contenedor.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout ContenedorLayout = new javax.swing.GroupLayout(Contenedor);
        Contenedor.setLayout(ContenedorLayout);
        ContenedorLayout.setHorizontalGroup(
            ContenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
        ContenedorLayout.setVerticalGroup(
            ContenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(51, 73, 94));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/Imagen_Usuario.png"))); // NOI18N
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 16, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nivel");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(102, 22, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Usuario");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(102, 56, -1, -1));

        btnConfig.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/Configuracion.png"))); // NOI18N
        btnConfig.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnConfigMouseClicked(evt);
            }
        });
        jPanel2.add(btnConfig, new org.netbeans.lib.awtextra.AbsoluteConstraints(161, 17, -1, -1));

        jPanel3.setBackground(new java.awt.Color(51, 73, 94));

        PanelTrabajador.setBackground(new java.awt.Color(51, 73, 94));
        PanelTrabajador.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PanelTrabajadorMouseMoved(evt);
            }
        });

        LineTrabajador.setBackground(new java.awt.Color(51, 73, 94));

        javax.swing.GroupLayout LineTrabajadorLayout = new javax.swing.GroupLayout(LineTrabajador);
        LineTrabajador.setLayout(LineTrabajadorLayout);
        LineTrabajadorLayout.setHorizontalGroup(
            LineTrabajadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );
        LineTrabajadorLayout.setVerticalGroup(
            LineTrabajadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        lblTrabajador.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        lblTrabajador.setForeground(new java.awt.Color(255, 255, 255));
        lblTrabajador.setText("Gestion Trabajador");
        lblTrabajador.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                lblTrabajadorMouseMoved(evt);
            }
        });
        lblTrabajador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTrabajadorMouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/transportador.png"))); // NOI18N

        javax.swing.GroupLayout PanelTrabajadorLayout = new javax.swing.GroupLayout(PanelTrabajador);
        PanelTrabajador.setLayout(PanelTrabajadorLayout);
        PanelTrabajadorLayout.setHorizontalGroup(
            PanelTrabajadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTrabajadorLayout.createSequentialGroup()
                .addComponent(LineTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTrabajador)
                .addContainerGap(18, Short.MAX_VALUE))
        );
        PanelTrabajadorLayout.setVerticalGroup(
            PanelTrabajadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LineTrabajador, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelTrabajadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(lblTrabajador, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelCliente.setBackground(new java.awt.Color(51, 73, 94));
        PanelCliente.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PanelClienteMouseMoved(evt);
            }
        });

        LineCliente.setBackground(new java.awt.Color(51, 73, 94));

        javax.swing.GroupLayout LineClienteLayout = new javax.swing.GroupLayout(LineCliente);
        LineCliente.setLayout(LineClienteLayout);
        LineClienteLayout.setHorizontalGroup(
            LineClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );
        LineClienteLayout.setVerticalGroup(
            LineClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        lblCliente.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        lblCliente.setForeground(new java.awt.Color(255, 255, 255));
        lblCliente.setText("Gestion Clientes");
        lblCliente.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                lblClienteMouseMoved(evt);
            }
        });
        lblCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblClienteMouseClicked(evt);
            }
        });

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/soporte-tecnico - copia.png"))); // NOI18N

        javax.swing.GroupLayout PanelClienteLayout = new javax.swing.GroupLayout(PanelCliente);
        PanelCliente.setLayout(PanelClienteLayout);
        PanelClienteLayout.setHorizontalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClienteLayout.createSequentialGroup()
                .addComponent(LineCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addComponent(lblCliente)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelClienteLayout.setVerticalGroup(
            PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LineCliente, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(lblCliente, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelUsuarios.setBackground(new java.awt.Color(51, 73, 94));
        PanelUsuarios.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PanelUsuariosMouseMoved(evt);
            }
        });

        LineUsuarios.setBackground(new java.awt.Color(51, 73, 94));

        javax.swing.GroupLayout LineUsuariosLayout = new javax.swing.GroupLayout(LineUsuarios);
        LineUsuarios.setLayout(LineUsuariosLayout);
        LineUsuariosLayout.setHorizontalGroup(
            LineUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );
        LineUsuariosLayout.setVerticalGroup(
            LineUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        lblUsuario.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        lblUsuario.setForeground(new java.awt.Color(255, 255, 255));
        lblUsuario.setText("Gestion Usuarios");
        lblUsuario.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                lblUsuarioMouseMoved(evt);
            }
        });
        lblUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUsuarioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblUsuarioMouseEntered(evt);
            }
        });

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/usuario.png"))); // NOI18N

        javax.swing.GroupLayout PanelUsuariosLayout = new javax.swing.GroupLayout(PanelUsuarios);
        PanelUsuarios.setLayout(PanelUsuariosLayout);
        PanelUsuariosLayout.setHorizontalGroup(
            PanelUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelUsuariosLayout.createSequentialGroup()
                .addComponent(LineUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(lblUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelUsuariosLayout.setVerticalGroup(
            PanelUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LineUsuarios, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(lblUsuario, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelProyecto.setBackground(new java.awt.Color(51, 73, 94));
        PanelProyecto.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PanelProyectoMouseMoved(evt);
            }
        });

        LineProyecto.setBackground(new java.awt.Color(51, 73, 94));

        javax.swing.GroupLayout LineProyectoLayout = new javax.swing.GroupLayout(LineProyecto);
        LineProyecto.setLayout(LineProyectoLayout);
        LineProyectoLayout.setHorizontalGroup(
            LineProyectoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );
        LineProyectoLayout.setVerticalGroup(
            LineProyectoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        lblProyecto.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        lblProyecto.setForeground(new java.awt.Color(255, 255, 255));
        lblProyecto.setText("Gestion Proyecto");
        lblProyecto.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                lblProyectoMouseMoved(evt);
            }
        });
        lblProyecto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblProyectoMouseClicked(evt);
            }
        });

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/gestion-de-proyectos.png"))); // NOI18N

        javax.swing.GroupLayout PanelProyectoLayout = new javax.swing.GroupLayout(PanelProyecto);
        PanelProyecto.setLayout(PanelProyectoLayout);
        PanelProyectoLayout.setHorizontalGroup(
            PanelProyectoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelProyectoLayout.createSequentialGroup()
                .addComponent(LineProyecto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblProyecto, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelProyectoLayout.setVerticalGroup(
            PanelProyectoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LineProyecto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelProyectoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(lblProyecto, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelBodega.setBackground(new java.awt.Color(51, 73, 94));
        PanelBodega.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PanelBodegaMouseMoved(evt);
            }
        });

        LineBodega.setBackground(new java.awt.Color(51, 73, 94));

        javax.swing.GroupLayout LineBodegaLayout = new javax.swing.GroupLayout(LineBodega);
        LineBodega.setLayout(LineBodegaLayout);
        LineBodegaLayout.setHorizontalGroup(
            LineBodegaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );
        LineBodegaLayout.setVerticalGroup(
            LineBodegaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        lblBodega.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        lblBodega.setForeground(new java.awt.Color(255, 255, 255));
        lblBodega.setText("Gestion Bodega");
        lblBodega.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                lblBodegaMouseMoved(evt);
            }
        });
        lblBodega.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBodegaMouseClicked(evt);
            }
        });

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/fabrica.png"))); // NOI18N

        javax.swing.GroupLayout PanelBodegaLayout = new javax.swing.GroupLayout(PanelBodega);
        PanelBodega.setLayout(PanelBodegaLayout);
        PanelBodegaLayout.setHorizontalGroup(
            PanelBodegaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelBodegaLayout.createSequentialGroup()
                .addComponent(LineBodega, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addComponent(lblBodega)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelBodegaLayout.setVerticalGroup(
            PanelBodegaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LineBodega, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelBodegaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(lblBodega, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel18, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelReportes.setBackground(new java.awt.Color(51, 73, 94));
        PanelReportes.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PanelReportesMouseMoved(evt);
            }
        });

        LineReportes.setBackground(new java.awt.Color(51, 73, 94));

        javax.swing.GroupLayout LineReportesLayout = new javax.swing.GroupLayout(LineReportes);
        LineReportes.setLayout(LineReportesLayout);
        LineReportesLayout.setHorizontalGroup(
            LineReportesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );
        LineReportesLayout.setVerticalGroup(
            LineReportesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        lblReporte.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        lblReporte.setForeground(new java.awt.Color(255, 255, 255));
        lblReporte.setText("Reportes y Datos");
        lblReporte.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                lblReporteMouseMoved(evt);
            }
        });
        lblReporte.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblReporteMouseClicked(evt);
            }
        });

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/seo-report.png"))); // NOI18N

        javax.swing.GroupLayout PanelReportesLayout = new javax.swing.GroupLayout(PanelReportes);
        PanelReportes.setLayout(PanelReportesLayout);
        PanelReportesLayout.setHorizontalGroup(
            PanelReportesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelReportesLayout.createSequentialGroup()
                .addComponent(LineReportes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(lblReporte)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelReportesLayout.setVerticalGroup(
            PanelReportesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LineReportes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelReportesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(lblReporte, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelEmpresa.setBackground(new java.awt.Color(51, 73, 94));
        PanelEmpresa.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PanelEmpresaMouseMoved(evt);
            }
        });

        LineEmpresa.setBackground(new java.awt.Color(51, 73, 94));

        javax.swing.GroupLayout LineEmpresaLayout = new javax.swing.GroupLayout(LineEmpresa);
        LineEmpresa.setLayout(LineEmpresaLayout);
        LineEmpresaLayout.setHorizontalGroup(
            LineEmpresaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );
        LineEmpresaLayout.setVerticalGroup(
            LineEmpresaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        lblEmpresa.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        lblEmpresa.setForeground(new java.awt.Color(255, 255, 255));
        lblEmpresa.setText("Gestion Empresa");
        lblEmpresa.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                lblEmpresaMouseMoved(evt);
            }
        });
        lblEmpresa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEmpresaMouseClicked(evt);
            }
        });

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/empresa.png"))); // NOI18N

        javax.swing.GroupLayout PanelEmpresaLayout = new javax.swing.GroupLayout(PanelEmpresa);
        PanelEmpresa.setLayout(PanelEmpresaLayout);
        PanelEmpresaLayout.setHorizontalGroup(
            PanelEmpresaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelEmpresaLayout.createSequentialGroup()
                .addComponent(LineEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel20)
                .addGap(18, 18, 18)
                .addComponent(lblEmpresa)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelEmpresaLayout.setVerticalGroup(
            PanelEmpresaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LineEmpresa, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelEmpresaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(lblEmpresa, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelHistorial.setBackground(new java.awt.Color(51, 73, 94));
        PanelHistorial.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PanelHistorialMouseMoved(evt);
            }
        });

        LineHistorial.setBackground(new java.awt.Color(51, 73, 94));

        javax.swing.GroupLayout LineHistorialLayout = new javax.swing.GroupLayout(LineHistorial);
        LineHistorial.setLayout(LineHistorialLayout);
        LineHistorialLayout.setHorizontalGroup(
            LineHistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );
        LineHistorialLayout.setVerticalGroup(
            LineHistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        lblHistorial.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        lblHistorial.setForeground(new java.awt.Color(255, 255, 255));
        lblHistorial.setText("Historial Cambios");
        lblHistorial.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                lblHistorialMouseMoved(evt);
            }
        });
        lblHistorial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblHistorialMouseClicked(evt);
            }
        });

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconografia/biografia.png"))); // NOI18N

        javax.swing.GroupLayout PanelHistorialLayout = new javax.swing.GroupLayout(PanelHistorial);
        PanelHistorial.setLayout(PanelHistorialLayout);
        PanelHistorialLayout.setHorizontalGroup(
            PanelHistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelHistorialLayout.createSequentialGroup()
                .addComponent(LineHistorial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel22)
                .addGap(18, 18, 18)
                .addComponent(lblHistorial)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelHistorialLayout.setVerticalGroup(
            PanelHistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LineHistorial, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelHistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(lblHistorial, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/cerrar-sesion.png"))); // NOI18N
        jLabel23.setText("  Cerrar Sesion");
        jLabel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel23MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelTrabajador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelProyecto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelUsuarios, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelBodega, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelReportes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelEmpresa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelHistorial, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel23))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(PanelTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(PanelCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PanelProyecto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PanelUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PanelBodega, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PanelReportes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PanelEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PanelHistorial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BarraTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 1280, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(Contenedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(BarraTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Contenedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    Configuracion_Personal config = new Configuracion_Personal();
    frmHistorial historial = new frmHistorial();
    frmEstadistica estadis = new frmEstadistica();
    frmGestionBodegas bodegas = new frmGestionBodegas();
    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        System.exit(1);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void BarraTituloMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BarraTituloMousePressed
        FiveCodMoverJFrame.MousePressed(evt);
    }//GEN-LAST:event_BarraTituloMousePressed

    private void BarraTituloMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BarraTituloMouseDragged
        FiveCodMoverJFrame.MouseDraggedFrame(evt, this);
    }//GEN-LAST:event_BarraTituloMouseDragged

    private void btnConfigMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConfigMouseClicked
        config.setLocation(5,5);
        config.setSize(1000,640);
        Contenedor.removeAll();
        Contenedor.add(config,BorderLayout.CENTER);
        Contenedor.revalidate();
        Contenedor.repaint();
    }//GEN-LAST:event_btnConfigMouseClicked

    private void lblMinimizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMinimizarMouseClicked
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_lblMinimizarMouseClicked

     void desactivarHover()
    {
        PanelTrabajador.setBackground(new java.awt.Color(51,73,94));
        LineTrabajador.setBackground(new java.awt.Color(51,73,94));
        PanelCliente.setBackground(new java.awt.Color(51,73,94));
        LineCliente.setBackground(new java.awt.Color(51,73,94));  
        PanelProyecto.setBackground(new java.awt.Color(51,73,94));
        LineProyecto.setBackground(new java.awt.Color(51,73,94));
        PanelUsuarios.setBackground(new java.awt.Color(51,73,94));
        LineUsuarios.setBackground(new java.awt.Color(51,73,94));
        PanelBodega.setBackground(new java.awt.Color(51,73,94));
        LineBodega.setBackground(new java.awt.Color(51,73,94));
        PanelReportes.setBackground(new java.awt.Color(51,73,94));
        LineReportes.setBackground(new java.awt.Color(51,73,94));  
        PanelEmpresa.setBackground(new java.awt.Color(51,73,94));
        LineEmpresa.setBackground(new java.awt.Color(51,73,94));
        PanelHistorial.setBackground(new java.awt.Color(51,73,94));
        LineHistorial.setBackground(new java.awt.Color(51,73,94));        
    }
    
    void hovertrabajador()
    {
        desactivarHover();
        PanelTrabajador.setBackground(new java.awt.Color(33,50,66));
        LineTrabajador.setBackground(new java.awt.Color(25,167,224));        
    }
    
    void hoverClientes()
    {
        desactivarHover();
        PanelCliente.setBackground(new java.awt.Color(33,50,66));
        LineCliente.setBackground(new java.awt.Color(25,167,224));        
    }
    
    void hoverProyecto()
    {
        desactivarHover();
        PanelProyecto.setBackground(new java.awt.Color(33,50,66));
        LineProyecto.setBackground(new java.awt.Color(25,167,224));        
    }
    
    void hoverUsuario()
    {
        desactivarHover();
        PanelUsuarios.setBackground(new java.awt.Color(33,50,66));
        LineUsuarios.setBackground(new java.awt.Color(25,167,224));        
    }
    
    void hoverBodega()
    {
        desactivarHover();
        PanelBodega.setBackground(new java.awt.Color(33,50,66));
        LineBodega.setBackground(new java.awt.Color(25,167,224));        
    }
    
    void hoverReportes()
    {
        desactivarHover();
        PanelReportes.setBackground(new java.awt.Color(33,50,66));
        LineReportes.setBackground(new java.awt.Color(25,167,224));        
    }
    
    void hoverEmpresa()
    {
        desactivarHover();
        PanelEmpresa.setBackground(new java.awt.Color(33,50,66));
        LineEmpresa.setBackground(new java.awt.Color(25,167,224));        
    }
    
    void hoverHistorial()
    {
        desactivarHover();
        PanelHistorial.setBackground(new java.awt.Color(33,50,66));
        LineHistorial.setBackground(new java.awt.Color(25,167,224));        
    }
    
    private void PanelTrabajadorMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelTrabajadorMouseMoved
        hovertrabajador();
    }//GEN-LAST:event_PanelTrabajadorMouseMoved

    private void PanelClienteMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelClienteMouseMoved
        hoverClientes();
    }//GEN-LAST:event_PanelClienteMouseMoved

    private void PanelProyectoMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelProyectoMouseMoved
        hoverProyecto();
    }//GEN-LAST:event_PanelProyectoMouseMoved

    private void PanelUsuariosMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelUsuariosMouseMoved
        hoverUsuario();
    }//GEN-LAST:event_PanelUsuariosMouseMoved

    private void PanelBodegaMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelBodegaMouseMoved
        hoverBodega();
    }//GEN-LAST:event_PanelBodegaMouseMoved

    private void PanelReportesMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelReportesMouseMoved
        hoverReportes();
    }//GEN-LAST:event_PanelReportesMouseMoved

    private void PanelEmpresaMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelEmpresaMouseMoved
        hoverEmpresa();
    }//GEN-LAST:event_PanelEmpresaMouseMoved

    private void PanelHistorialMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelHistorialMouseMoved
        hoverHistorial();
    }//GEN-LAST:event_PanelHistorialMouseMoved

    private void jLabel23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel23MouseClicked
        Login c = new Login();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel23MouseClicked

    private void lblHistorialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHistorialMouseClicked
        historial.setLocation(0,0);
        historial.setSize(960,655);
        Contenedor.removeAll();
        Contenedor.add(historial,BorderLayout.CENTER);
        Contenedor.revalidate();
        Contenedor.repaint();
    }//GEN-LAST:event_lblHistorialMouseClicked

    private void lblHistorialMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHistorialMouseMoved
         hoverHistorial();
    }//GEN-LAST:event_lblHistorialMouseMoved

    private void lblEmpresaMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEmpresaMouseMoved
        hoverEmpresa();
    }//GEN-LAST:event_lblEmpresaMouseMoved

    private void lblReporteMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblReporteMouseMoved
        hoverReportes();
    }//GEN-LAST:event_lblReporteMouseMoved

    private void lblBodegaMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBodegaMouseMoved
        hoverBodega();
    }//GEN-LAST:event_lblBodegaMouseMoved

    private void lblUsuarioMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuarioMouseMoved
        hoverUsuario();
    }//GEN-LAST:event_lblUsuarioMouseMoved

    private void lblProyectoMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProyectoMouseMoved
        hoverProyecto();
    }//GEN-LAST:event_lblProyectoMouseMoved

    private void lblClienteMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblClienteMouseMoved
        hoverClientes();
    }//GEN-LAST:event_lblClienteMouseMoved

    private void lblTrabajadorMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTrabajadorMouseMoved
        hovertrabajador();
    }//GEN-LAST:event_lblTrabajadorMouseMoved
    
    private void lblReporteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblReporteMouseClicked
        estadis.setLocation(0,0);
        estadis.setSize(970,655);
        Contenedor.removeAll();
        Contenedor.add(estadis,BorderLayout.CENTER);
        Contenedor.revalidate();
        Contenedor.repaint();
    }//GEN-LAST:event_lblReporteMouseClicked

    private void lblBodegaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBodegaMouseClicked
        bodegas.setLocation(0,0);
        bodegas.setSize(970,655);
        Contenedor.removeAll();
        Contenedor.add(bodegas,BorderLayout.CENTER);
        Contenedor.revalidate();
        Contenedor.repaint();
    }//GEN-LAST:event_lblBodegaMouseClicked
        Gestion_Trabajadores traba = new Gestion_Trabajadores();
    private void lblTrabajadorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTrabajadorMouseClicked
        traba.setLocation(0,0);
        traba.setSize(970,655);
        Contenedor.removeAll();
        Contenedor.add(traba,BorderLayout.CENTER);
        Contenedor.revalidate();
        Contenedor.repaint();
    }//GEN-LAST:event_lblTrabajadorMouseClicked

    private void lblUsuarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuarioMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_lblUsuarioMouseEntered
    Gestion_Usuarios user = new Gestion_Usuarios();
    private void lblUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuarioMouseClicked
        user.setLocation(0,0);
        user.setSize(1000,655);
        Contenedor.removeAll();
        Contenedor.add(user,BorderLayout.CENTER);
        Contenedor.revalidate();
        Contenedor.repaint();
    }//GEN-LAST:event_lblUsuarioMouseClicked
    Gestion_Cliente cli = new Gestion_Cliente();
    private void lblClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblClienteMouseClicked
        cli.setLocation(0,0);
        cli.setSize(1000,655);
        Contenedor.removeAll();
        Contenedor.add(cli,BorderLayout.CENTER);
        Contenedor.revalidate();
        Contenedor.repaint();
    }//GEN-LAST:event_lblClienteMouseClicked
    Gestion_Empresa empresa = new Gestion_Empresa();
    private void lblEmpresaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEmpresaMouseClicked
        empresa.setLocation(0,0);
        empresa.setSize(1000,655);
        Contenedor.removeAll();
        Contenedor.add(empresa,BorderLayout.CENTER);
        Contenedor.revalidate();
        Contenedor.repaint();
    }//GEN-LAST:event_lblEmpresaMouseClicked
    panel_inicial proyec = new panel_inicial();
    private void lblProyectoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProyectoMouseClicked
        proyec.setLocation(0,0);
        proyec.setSize(1000,655);
        Contenedor.removeAll();
        Contenedor.add(proyec,BorderLayout.CENTER);
        Contenedor.revalidate();
        Contenedor.repaint();
    }//GEN-LAST:event_lblProyectoMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu_Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BarraTitulo;
    private javax.swing.JPanel Contenedor;
    private javax.swing.JPanel LineBodega;
    private javax.swing.JPanel LineCliente;
    private javax.swing.JPanel LineEmpresa;
    private javax.swing.JPanel LineHistorial;
    private javax.swing.JPanel LineProyecto;
    private javax.swing.JPanel LineReportes;
    private javax.swing.JPanel LineTrabajador;
    private javax.swing.JPanel LineUsuarios;
    private javax.swing.JPanel PanelBodega;
    private javax.swing.JPanel PanelCliente;
    private javax.swing.JPanel PanelEmpresa;
    private javax.swing.JPanel PanelHistorial;
    private javax.swing.JPanel PanelProyecto;
    private javax.swing.JPanel PanelReportes;
    private javax.swing.JPanel PanelTrabajador;
    private javax.swing.JPanel PanelUsuarios;
    private javax.swing.JLabel btnConfig;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblBodega;
    private javax.swing.JLabel lblCliente;
    private javax.swing.JLabel lblEmpresa;
    private javax.swing.JLabel lblHistorial;
    private javax.swing.JLabel lblMinimizar;
    private javax.swing.JLabel lblProyecto;
    private javax.swing.JLabel lblReporte;
    private javax.swing.JLabel lblTrabajador;
    private javax.swing.JLabel lblUsuario;
    // End of variables declaration//GEN-END:variables
}
